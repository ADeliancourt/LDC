DELIMITER $$
CREATE FUNCTION `identification`( P_Login varchar(50),P_Pass varchar(20)) returns int
BEGIN
	declare nb_couple int;
        declare solution int;
	select  count(*) into nb_couple from membre where membreLogin='P_Login' and membreMdp='P_Pass';
		IF (nb_couple=0) THEN
        	set solution=1;
        ELSE
		set solution=0;                
   	END IF;
return solution;
END$$
DELIMITER ;
