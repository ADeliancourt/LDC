<?php
include("commun.php");
//requete sql
if(isset($_GET['action'])&& $_GET['action']=='ajout')
{
	$noListeEnCours=0;
	$action=$_GET['action'];
	switch($action)
	{
		case "acheter":break;
		case "annuler":break;
		case "reporter":break;
	}
}
//son numéro, son libellé, la quantité à acheter, le numéro du rayon dans lequel il est ainsi que le libellé de ce rayon.

$sql = "select produit.produitId as produitId, produitLib, listeQte, rayon.rayonId as rayonId, rayonLib 
	from produit 	inner join rayon on rayon.rayonId=produit.rayonId
			inner join contenuListe on contenuListe.produitId=produit.produitId
			inner join liste on liste.listeId = contenuListe.listeId
	where enCours=true 
	and contenuListe.listeId = $noListeEnCours"; 
//execution
$result = mysql_query($sql);
//le tableau
$monTableau = array();
if(mysql_num_rows($result))//s'il y a un resultat
{
	while($ligne=mysql_fetch_assoc($result))
	{
		$monTableau['coursesAFaire'][]=$ligne;
	}
}
echo json_encode($monTableau); 
?> 
