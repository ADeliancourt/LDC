/** Automatically generated file. DO NOT MODIFY */
package com.example.ldcorig;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}