/** Automatically generated file. DO NOT MODIFY */
package com.example.listedecourse;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}