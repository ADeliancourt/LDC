package com.example.ldcorig;


//definir une interface de CallBack
interface InterfaceDeCallBack {

    void receptionDonneesTerminee(String result);
}

