package com.example.ldcorig;

import android.os.Bundle;
import android.util.Log;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.listedecourse.R;

public class FaireCourseActivity extends BaseActivity {

	// quelques propriétés de la classe:

	private String url = "faireCourse.php";

	public String url() {
		return baseUrl + url;
	};

	private ExpandableListView listeViewDesProduitsDeLaListeParRayon;

	// code s'exécutant à la création de l'activité
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// on charge la bonne interface (layout)
		setContentView(R.layout.activity_faire_courses);
		listeViewDesProduitsDeLaListeParRayon = (ExpandableListView) findViewById(R.id.expandableListViewProduitsDansListe);
	}

	public void traiterDonneesRecues(String jsonResult) {

		EnsembleDeRayons ensRayons = new EnsembleDeRayons();
		try {
			JSONObject jsonResponse = new JSONObject(jsonResult);
			JSONArray jsonMainNode = jsonResponse.optJSONArray("coursesAFaire");

			for (int i = 0; i < jsonMainNode.length(); i++) {
				JSONObject jsonChildNode = jsonMainNode.getJSONObject(i);
				String productName = jsonChildNode.optString("produitLib");
				String productNumber = jsonChildNode.optString("produitId");

				String rayName = jsonChildNode.optString("rayonLib");
				String rayNumber = jsonChildNode.optString("rayonId");

				String listeQte = jsonChildNode.optString("listeQte");

				// IDIDIT on stock ces info qlq part
				ensRayons.addArticle(productNumber, productName, rayNumber,
						rayName, listeQte);
				
			}
		} catch (JSONException e) {
			Toast.makeText(getApplicationContext(), "Error" + e.toString(),
					Toast.LENGTH_SHORT).show();
		}

		// création de l'adapteur pour le choix du rayon qd on fait la liste de
		// course
		AdapterExpandableRayonsProduits monAdapteur = new AdapterExpandableRayonsProduits(
				this, ensRayons);
		monAdapteur.setEnsRayon(ensRayons);
		
		

		try {
			// on associe l'adaptateur à la listView
			listeViewDesProduitsDeLaListeParRayon.setAdapter(monAdapteur);

		} catch (NullPointerException e) {

			Log.i("ListeDeCourse",
					listeViewDesProduitsDeLaListeParRayon.toString());

		}
	}

	private HashMap<String, String> creerMapRayon(String name, String number) {
		HashMap<String, String> mapRayon = new HashMap<String, String>();
		mapRayon.put("rayonId", number);
		mapRayon.put("rayonLib", name);
		return mapRayon;
	}
}
